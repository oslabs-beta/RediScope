import ReactDOM from "react-dom";
import { App } from "./App";
// import '../src/stylesheets/styles.css';


ReactDOM.render(<App />, document.getElementById("root"));
