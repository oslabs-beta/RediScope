declare module '*.png';
declare module '*.jpeg';
declare module '*.jpg';
declare module '*.gif';
